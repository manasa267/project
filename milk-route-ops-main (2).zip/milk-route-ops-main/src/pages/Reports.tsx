import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Download } from "lucide-react";

const Reports = () => {
  const [reportType, setReportType] = useState<"day" | "month">("day");
  const [selectedDate, setSelectedDate] = useState("");
  const [reportData, setReportData] = useState<{
    milkSales: any[];
    productSales: any[];
    totalMilkRevenue: number;
    totalProductRevenue: number;
    totalRevenue: number;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/auth");
      }
    };
    checkAuth();

    // Set today's date as default
    const today = new Date().toISOString().split("T")[0];
    setSelectedDate(today);
  }, [navigate]);

  const generateReport = async () => {
    if (!selectedDate) {
      toast({
        title: "Error",
        description: "Please select a date",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsLoading(true);

      let startDate: string;
      let endDate: string;

      if (reportType === "day") {
        startDate = selectedDate;
        endDate = selectedDate;
      } else {
        // For month input, value is "YYYY-MM"
        const [year, month] = selectedDate.split("-").map(Number);
        startDate = `${year}-${String(month).padStart(2, "0")}-01`;
        // Get last day of month
        const lastDay = new Date(year, month, 0).getDate();
        endDate = `${year}-${String(month).padStart(2, "0")}-${lastDay}`;
      }

      // Fetch milk sales
      const { data: milkSales, error: milkError } = await supabase
        .from("milk_sales")
        .select("*, farmers(farmer_name)")
        .gte("sale_date", startDate)
        .lte("sale_date", endDate)
        .order("sale_date", { ascending: false });

      // Fetch product sales
      const { data: productSales, error: productError } = await supabase
        .from("products")
        .select("*")
        .gte("sale_date", startDate)
        .lte("sale_date", endDate)
        .order("sale_date", { ascending: false });

      if (milkError || productError) {
        throw new Error("Failed to fetch sales data");
      }

      const totalMilkRevenue = milkSales?.reduce((sum, sale) => sum + Number(sale.total_amount), 0) || 0;
      const totalProductRevenue = productSales?.reduce((sum, sale) => sum + Number(sale.total_price), 0) || 0;

      setReportData({
        milkSales: milkSales || [],
        productSales: productSales || [],
        totalMilkRevenue,
        totalProductRevenue,
        totalRevenue: totalMilkRevenue + totalProductRevenue,
      });

      toast({
        title: "Success",
        description: "Report generated successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate report",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Generate Reports
          </h1>
          <p className="text-muted-foreground mt-2">
            View sales reports by date or month
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Report Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label>Report Type</Label>
                <div className="flex gap-2">
                  <Button
                    variant={reportType === "day" ? "default" : "outline"}
                    onClick={() => setReportType("day")}
                  >
                    Daily
                  </Button>
                  <Button
                    variant={reportType === "month" ? "default" : "outline"}
                    onClick={() => setReportType("month")}
                  >
                    Monthly
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="date">
                  {reportType === "day" ? "Select Date" : "Select Month"}
                </Label>
                <Input
                  id="date"
                  type={reportType === "day" ? "date" : "month"}
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                />
              </div>
              <div className="flex items-end">
                <Button onClick={generateReport} disabled={isLoading} className="w-full">
                  {isLoading ? "Generating..." : "Generate Report"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {reportData && (
          <div className="space-y-6">
            <div className="grid gap-6 md:grid-cols-3">
              <Card className="bg-gradient-to-br from-primary/10 to-primary/5">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Milk Sales Revenue</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-primary">
                    ₹{reportData.totalMilkRevenue.toFixed(2)}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-secondary/10 to-secondary/5">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Product Sales Revenue</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-secondary">
                    ₹{reportData.totalProductRevenue.toFixed(2)}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-primary/10 via-secondary/10 to-primary/10">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                    ₹{reportData.totalRevenue.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Milk Sales Details</CardTitle>
              </CardHeader>
              <CardContent>
                {reportData.milkSales.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Farmer</TableHead>
                        <TableHead>Quantity (L)</TableHead>
                        <TableHead>Price/L</TableHead>
                        <TableHead>Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reportData.milkSales.map((sale) => (
                        <TableRow key={sale.sale_id}>
                          <TableCell>{new Date(sale.sale_date).toLocaleDateString()}</TableCell>
                          <TableCell>{sale.farmers?.farmer_name || "N/A"}</TableCell>
                          <TableCell>{Number(sale.milk_quantity).toFixed(2)}</TableCell>
                          <TableCell>₹{Number(sale.price_per_liter).toFixed(2)}</TableCell>
                          <TableCell className="font-medium">₹{Number(sale.total_amount).toFixed(2)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <p className="text-center text-muted-foreground py-4">No milk sales found for this period</p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Product Sales Details</CardTitle>
              </CardHeader>
              <CardContent>
                {reportData.productSales.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Product</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Price/Unit</TableHead>
                        <TableHead>Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reportData.productSales.map((sale) => (
                        <TableRow key={sale.product_id}>
                          <TableCell>{new Date(sale.sale_date).toLocaleDateString()}</TableCell>
                          <TableCell>{sale.product_name}</TableCell>
                          <TableCell>{Number(sale.quantity).toFixed(2)}</TableCell>
                          <TableCell>₹{Number(sale.price_per_unit).toFixed(2)}</TableCell>
                          <TableCell className="font-medium">₹{Number(sale.total_price).toFixed(2)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <p className="text-center text-muted-foreground py-4">No product sales found for this period</p>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Reports;