import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import AddFarmer from "@/components/services/AddFarmer";
import AddAnimal from "@/components/services/AddAnimal";
import AddStaff from "@/components/services/AddStaff";
import BillGeneration from "@/components/services/BillGeneration";
import DairyProducts from "@/components/services/DairyProducts";
import FarmerInfo from "@/components/services/FarmerInfo";
import FarmersList from "@/components/services/FarmersList";

const Services = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/auth");
      }
    };
    checkAuth();
  }, [navigate]);

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Services
          </h1>
          <p className="text-muted-foreground mt-2">
            Manage all dairy operations from one place
          </p>
        </div>

        <Tabs defaultValue="farmer" className="w-full">
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-7">
            <TabsTrigger value="farmer">Add Farmer</TabsTrigger>
            <TabsTrigger value="farmersList">Farmers List</TabsTrigger>
            <TabsTrigger value="animal">Add Animal</TabsTrigger>
            <TabsTrigger value="staff">Add Staff</TabsTrigger>
            <TabsTrigger value="bill">Bill Generation</TabsTrigger>
            <TabsTrigger value="products">Dairy Products</TabsTrigger>
            <TabsTrigger value="info">Farmer Info</TabsTrigger>
          </TabsList>

          <TabsContent value="farmer" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Add New Farmer</CardTitle>
                <CardDescription>Register a new farmer in the system</CardDescription>
              </CardHeader>
              <CardContent>
                <AddFarmer />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="farmersList" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Farmers List</CardTitle>
                <CardDescription>View and manage all registered farmers</CardDescription>
              </CardHeader>
              <CardContent>
                <FarmersList />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="animal" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Add New Animal</CardTitle>
                <CardDescription>Register a new animal for a farmer</CardDescription>
              </CardHeader>
              <CardContent>
                <AddAnimal />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="staff" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Add Staff Member</CardTitle>
                <CardDescription>Register a new staff member</CardDescription>
              </CardHeader>
              <CardContent>
                <AddStaff />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="bill" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Generate Bill</CardTitle>
                <CardDescription>Create a milk sale transaction</CardDescription>
              </CardHeader>
              <CardContent>
                <BillGeneration />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="products" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Dairy Products</CardTitle>
                <CardDescription>Manage dairy product sales</CardDescription>
              </CardHeader>
              <CardContent>
                <DairyProducts />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="info" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Farmer Information</CardTitle>
                <CardDescription>View detailed information about a farmer</CardDescription>
              </CardHeader>
              <CardContent>
                <FarmerInfo />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Services;