import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { Target, Users, TrendingUp, Shield } from "lucide-react";

const About = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/auth");
      }
    };
    checkAuth();
  }, [navigate]);

  const features = [
    {
      icon: Target,
      title: "Our Mission",
      description: "To provide a comprehensive, efficient, and user-friendly dairy management solution that helps dairy businesses streamline their operations and maximize productivity.",
    },
    {
      icon: Users,
      title: "Farmer Management",
      description: "Complete farmer database with contact information, animal details, and transaction history. Track all farmer relationships in one place.",
    },
    {
      icon: TrendingUp,
      title: "Sales Tracking",
      description: "Real-time monitoring of milk sales, product sales, and financial transactions. Generate detailed reports and insights for better decision-making.",
    },
    {
      icon: Shield,
      title: "Secure & Reliable",
      description: "Built with modern security practices and reliable backend infrastructure to ensure your data is always safe and accessible.",
    },
  ];

  return (
    <Layout>
      <div className="space-y-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            About Dairy Management System
          </h1>
          <p className="text-lg text-muted-foreground mt-4 max-w-2xl mx-auto">
            A modern, comprehensive solution for managing dairy operations efficiently
          </p>
        </div>

        <Card className="bg-gradient-to-br from-primary/10 to-secondary/10">
          <CardHeader>
            <CardTitle className="text-2xl">What We Offer</CardTitle>
          </CardHeader>
          <CardContent className="text-muted-foreground">
            <p className="mb-4">
              The Dairy Management System is designed to simplify and automate dairy farm operations. 
              From farmer registration to milk sales tracking, we provide all the tools you need to run 
              a successful dairy business.
            </p>
            <p>
              Our system helps you maintain detailed records, generate bills automatically, track inventory, 
              manage staff, and create comprehensive reports for better business insights.
            </p>
          </CardContent>
        </Card>

        <div className="grid gap-6 md:grid-cols-2">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-gradient-to-br from-primary to-secondary rounded-lg">
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle>{feature.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Key Features</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {[
                "Complete farmer and animal database management",
                "Staff member registration and tracking",
                "Automated bill generation for milk sales",
                "Dairy product inventory and sales management",
                "Comprehensive reporting with date-based filtering",
                "Secure authentication and data protection",
                "User-friendly interface with real-time updates",
                "Detailed farmer information lookup",
              ].map((feature, index) => (
                <li key={index} className="flex items-center gap-2">
                  <div className="h-2 w-2 bg-primary rounded-full"></div>
                  <span className="text-muted-foreground">{feature}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default About;