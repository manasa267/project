import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Beef, UserCog, TrendingUp, ShoppingBag, DollarSign } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

const Dashboard = () => {
  const [stats, setStats] = useState({
    farmers: 0,
    animals: 0,
    staff: 0,
    todaySales: 0,
  });
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/auth");
        return;
      }
      fetchStats();
    };

    checkAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session) {
        navigate("/auth");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const fetchStats = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      
      const [farmersRes, animalsRes, staffRes, salesRes] = await Promise.all([
        supabase.from("farmers").select("*", { count: "exact", head: true }),
        supabase.from("animals").select("*", { count: "exact", head: true }),
        supabase.from("staff").select("*", { count: "exact", head: true }),
        supabase.from("milk_sales").select("total_amount").eq("sale_date", today),
      ]);

      const todayTotal = salesRes.data?.reduce((sum, sale) => sum + Number(sale.total_amount), 0) || 0;

      setStats({
        farmers: farmersRes.count || 0,
        animals: animalsRes.count || 0,
        staff: staffRes.count || 0,
        todaySales: todayTotal,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load dashboard stats",
        variant: "destructive",
      });
    }
  };

  const statCards = [
    {
      title: "Total Farmers",
      value: stats.farmers,
      icon: Users,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      title: "Total Animals",
      value: stats.animals,
      icon: Beef,
      color: "text-secondary",
      bgColor: "bg-secondary/10",
    },
    {
      title: "Staff Members",
      value: stats.staff,
      icon: UserCog,
      color: "text-accent",
      bgColor: "bg-accent/10",
    },
    {
      title: "Today's Sales",
      value: `₹${stats.todaySales.toFixed(2)}`,
      icon: DollarSign,
      color: "text-secondary-light",
      bgColor: "bg-secondary/10",
    },
  ];

  return (
    <Layout>
      <div className="space-y-8">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Admin Dashboard
          </h1>
          <p className="text-muted-foreground mt-2">
            Welcome to the Dairy Management System
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {statCards.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    {stat.title}
                  </CardTitle>
                  <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                    <Icon className={`h-4 w-4 ${stat.color}`} />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Quick Actions
              </CardTitle>
              <CardDescription>Frequently used features</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <button
                onClick={() => navigate("/services")}
                className="w-full text-left px-4 py-3 rounded-lg bg-primary/10 hover:bg-primary/20 transition-colors"
              >
                <p className="font-semibold text-primary">Add New Farmer</p>
                <p className="text-sm text-muted-foreground">Register a new farmer</p>
              </button>
              <button
                onClick={() => navigate("/services")}
                className="w-full text-left px-4 py-3 rounded-lg bg-secondary/10 hover:bg-secondary/20 transition-colors"
              >
                <p className="font-semibold text-secondary">Generate Bill</p>
                <p className="text-sm text-muted-foreground">Create milk sale transaction</p>
              </button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingBag className="h-5 w-5 text-secondary" />
                System Overview
              </CardTitle>
              <CardDescription>Your dairy management at a glance</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                The Dairy Management System helps you efficiently manage farmers, animals, staff, 
                milk sales, and dairy products. Use the navigation menu to access different features.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;