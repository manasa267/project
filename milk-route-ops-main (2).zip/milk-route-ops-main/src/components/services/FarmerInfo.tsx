import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

interface FarmerData {
  farmer_name: string;
  contact_info: string;
  animal_type: string;
  animals: Array<{ animal_id: string; animal_type: string }>;
  totalMilkQuantity: number;
  totalAmount: number;
}

const FarmerInfo = () => {
  const [farmerId, setFarmerId] = useState("");
  const [farmerData, setFarmerData] = useState<FarmerData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSearch = async () => {
    if (!farmerId.trim()) {
      toast({
        title: "Error",
        description: "Please enter a Farmer ID",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsLoading(true);

      // Fetch farmer details
      const { data: farmer, error: farmerError } = await supabase
        .from("farmers")
        .select("farmer_name, contact_info, animal_type")
        .eq("farmer_id", farmerId)
        .single();

      if (farmerError || !farmer) {
        toast({
          title: "Error",
          description: "Farmer not found",
          variant: "destructive",
        });
        setFarmerData(null);
        return;
      }

      // Fetch animals
      const { data: animals, error: animalsError } = await supabase
        .from("animals")
        .select("animal_id, animal_type")
        .eq("farmer_id", farmerId);

      // Fetch milk sales
      const { data: sales, error: salesError } = await supabase
        .from("milk_sales")
        .select("milk_quantity, total_amount")
        .eq("farmer_id", farmerId);

      const totalMilkQuantity = sales?.reduce((sum, sale) => sum + Number(sale.milk_quantity), 0) || 0;
      const totalAmount = sales?.reduce((sum, sale) => sum + Number(sale.total_amount), 0) || 0;

      setFarmerData({
        farmer_name: farmer.farmer_name,
        contact_info: farmer.contact_info,
        animal_type: farmer.animal_type,
        animals: animals || [],
        totalMilkQuantity,
        totalAmount,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch farmer information",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex gap-4">
        <div className="flex-1 space-y-2">
          <Label htmlFor="farmerId">Farmer ID</Label>
          <Input
            id="farmerId"
            placeholder="Enter Farmer ID (e.g., F001)"
            value={farmerId}
            onChange={(e) => setFarmerId(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSearch()}
          />
        </div>
        <div className="flex items-end">
          <Button onClick={handleSearch} disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Searching...
              </>
            ) : (
              "Search"
            )}
          </Button>
        </div>
      </div>

      {farmerData && (
        <div className="space-y-6">
          <Card className="p-6 bg-gradient-to-br from-primary/5 to-secondary/5">
            <h3 className="text-2xl font-bold mb-4">Farmer Details</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Name</p>
                <p className="text-lg font-semibold">{farmerData.farmer_name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Contact</p>
                <p className="text-lg font-semibold">{farmerData.contact_info}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Primary Animal Type</p>
                <p className="text-lg font-semibold">{farmerData.animal_type}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Animals</p>
                <p className="text-lg font-semibold">{farmerData.animals.length}</p>
              </div>
            </div>
          </Card>

          {farmerData.animals.length > 0 && (
            <Card className="p-6">
              <h3 className="text-xl font-bold mb-4">Animals</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Animal ID</TableHead>
                    <TableHead>Type</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {farmerData.animals.map((animal) => (
                    <TableRow key={animal.animal_id}>
                      <TableCell className="font-medium">{animal.animal_id}</TableCell>
                      <TableCell>{animal.animal_type}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          )}

          <Card className="p-6">
            <h3 className="text-xl font-bold mb-4">Sales Summary</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 bg-primary/10 rounded-lg">
                <p className="text-sm text-muted-foreground">Total Milk Sold</p>
                <p className="text-2xl font-bold text-primary">{farmerData.totalMilkQuantity.toFixed(2)} L</p>
              </div>
              <div className="p-4 bg-secondary/10 rounded-lg">
                <p className="text-sm text-muted-foreground">Total Amount Earned</p>
                <p className="text-2xl font-bold text-secondary">₹{farmerData.totalAmount.toFixed(2)}</p>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default FarmerInfo;