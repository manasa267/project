import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

const farmerSchema = z.object({
  farmerId: z.string().trim().min(1, "Farmer ID is required").max(50, "Farmer ID must be less than 50 characters"),
  farmerName: z.string().trim().min(2, "Name must be at least 2 characters").max(100, "Name must be less than 100 characters"),
  animalType: z.enum(["Cow", "Buffalo"], { required_error: "Please select an animal type" }),
  contactInfo: z.string().trim().min(10, "Contact must be at least 10 characters").max(15, "Contact must be less than 15 characters"),
});

const AddFarmer = () => {
  const [formData, setFormData] = useState({
    farmerId: "",
    farmerName: "",
    animalType: "",
    contactInfo: "",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    try {
      const validatedData = farmerSchema.parse(formData);
      setIsLoading(true);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase.from("farmers").insert({
        farmer_id: validatedData.farmerId,
        farmer_name: validatedData.farmerName,
        animal_type: validatedData.animalType,
        contact_info: validatedData.contactInfo,
        created_by: user.id,
      });

      if (error) {
        if (error.code === "23505") {
          toast({
            title: "Error",
            description: "Farmer ID already exists",
            variant: "destructive",
          });
        } else {
          throw error;
        }
      } else {
        toast({
          title: "Success",
          description: "Farmer added successfully",
        });
        setFormData({ farmerId: "", farmerName: "", animalType: "", contactInfo: "" });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path) {
            newErrors[err.path[0]] = err.message;
          }
        });
        setErrors(newErrors);
      } else {
        toast({
          title: "Error",
          description: "Failed to add farmer",
          variant: "destructive",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="farmerId">Farmer ID</Label>
          <Input
            id="farmerId"
            placeholder="F001"
            value={formData.farmerId}
            onChange={(e) => setFormData({ ...formData, farmerId: e.target.value })}
          />
          {errors.farmerId && <p className="text-sm text-destructive">{errors.farmerId}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="farmerName">Farmer Name</Label>
          <Input
            id="farmerName"
            placeholder="John Doe"
            value={formData.farmerName}
            onChange={(e) => setFormData({ ...formData, farmerName: e.target.value })}
          />
          {errors.farmerName && <p className="text-sm text-destructive">{errors.farmerName}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="animalType">Primary Animal Type</Label>
          <Select onValueChange={(value) => setFormData({ ...formData, animalType: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Cow">Cow</SelectItem>
              <SelectItem value="Buffalo">Buffalo</SelectItem>
            </SelectContent>
          </Select>
          {errors.animalType && <p className="text-sm text-destructive">{errors.animalType}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="contactInfo">Contact Info</Label>
          <Input
            id="contactInfo"
            placeholder="9876543210"
            value={formData.contactInfo}
            onChange={(e) => setFormData({ ...formData, contactInfo: e.target.value })}
          />
          {errors.contactInfo && <p className="text-sm text-destructive">{errors.contactInfo}</p>}
        </div>
      </div>
      <Button type="submit" disabled={isLoading} className="w-full md:w-auto">
        {isLoading ? "Adding..." : "Add Farmer"}
      </Button>
    </form>
  );
};

export default AddFarmer;