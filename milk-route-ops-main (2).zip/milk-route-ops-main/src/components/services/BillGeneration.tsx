import { useState } from "react";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";

const billSchema = z.object({
  farmerId: z.string().trim().min(1, "Farmer ID is required"),
  milkQuantity: z.number().positive("Quantity must be positive").max(10000, "Quantity seems too high"),
  pricePerLiter: z.number().positive("Price must be positive").max(1000, "Price seems too high"),
});

const BillGeneration = () => {
  const [formData, setFormData] = useState({
    farmerId: "",
    milkQuantity: "",
    pricePerLiter: "50",
  });
  const [saleDate, setSaleDate] = useState<Date>(new Date());
  const [billPreview, setBillPreview] = useState<{
    farmerName: string;
    quantity: number;
    price: number;
    total: number;
    date: Date;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { toast } = useToast();

  const handleCalculate = async () => {
    setErrors({});
    try {
      const quantity = parseFloat(formData.milkQuantity);
      const price = parseFloat(formData.pricePerLiter);

      const validatedData = billSchema.parse({
        farmerId: formData.farmerId,
        milkQuantity: quantity,
        pricePerLiter: price,
      });

      // Fetch farmer details
      const { data: farmer, error } = await supabase
        .from("farmers")
        .select("farmer_name")
        .eq("farmer_id", validatedData.farmerId)
        .single();

      if (error || !farmer) {
        toast({
          title: "Error",
          description: "Farmer not found",
          variant: "destructive",
        });
        return;
      }

      const total = validatedData.milkQuantity * validatedData.pricePerLiter;
      setBillPreview({
        farmerName: farmer.farmer_name,
        quantity: validatedData.milkQuantity,
        price: validatedData.pricePerLiter,
        total,
        date: saleDate,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path) {
            newErrors[err.path[0]] = err.message;
          }
        });
        setErrors(newErrors);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!billPreview) return;

    try {
      setIsLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase.from("milk_sales").insert({
        farmer_id: formData.farmerId,
        milk_quantity: billPreview.quantity,
        price_per_liter: billPreview.price,
        total_amount: billPreview.total,
        sale_date: format(saleDate, "yyyy-MM-dd"),
        created_by: user.id,
      });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Bill generated and saved successfully",
      });
      setFormData({ farmerId: "", milkQuantity: "", pricePerLiter: "50" });
      setSaleDate(new Date());
      setBillPreview(null);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate bill",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div className="space-y-2">
          <Label htmlFor="farmerId">Farmer ID</Label>
          <Input
            id="farmerId"
            placeholder="F001"
            value={formData.farmerId}
            onChange={(e) => setFormData({ ...formData, farmerId: e.target.value })}
          />
          {errors.farmerId && <p className="text-sm text-destructive">{errors.farmerId}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="milkQuantity">Milk Quantity (Liters)</Label>
          <Input
            id="milkQuantity"
            type="number"
            step="0.01"
            placeholder="10.5"
            value={formData.milkQuantity}
            onChange={(e) => setFormData({ ...formData, milkQuantity: e.target.value })}
          />
          {errors.milkQuantity && <p className="text-sm text-destructive">{errors.milkQuantity}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="pricePerLiter">Price per Liter (₹)</Label>
          <Input
            id="pricePerLiter"
            type="number"
            step="0.01"
            placeholder="50.00"
            value={formData.pricePerLiter}
            onChange={(e) => setFormData({ ...formData, pricePerLiter: e.target.value })}
          />
          {errors.pricePerLiter && <p className="text-sm text-destructive">{errors.pricePerLiter}</p>}
        </div>
        <div className="space-y-2">
          <Label>Sale Date</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "w-full justify-start text-left font-normal",
                  !saleDate && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {saleDate ? format(saleDate, "PPP") : <span>Pick a date</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={saleDate}
                onSelect={(date) => date && setSaleDate(date)}
                initialFocus
                className={cn("p-3 pointer-events-auto")}
              />
            </PopoverContent>
          </Popover>
        </div>
      </div>

      <Button onClick={handleCalculate} variant="outline">
        Calculate Bill
      </Button>

      {billPreview && (
        <Card className="p-6 bg-gradient-to-br from-primary/5 to-secondary/5">
          <h3 className="text-xl font-semibold mb-4">Bill Preview</h3>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Farmer Name:</span>
              <span className="font-medium">{billPreview.farmerName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Sale Date:</span>
              <span className="font-medium">{format(billPreview.date, "PPP")}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Milk Quantity:</span>
              <span className="font-medium">{billPreview.quantity} L</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Price per Liter:</span>
              <span className="font-medium">₹{billPreview.price.toFixed(2)}</span>
            </div>
            <div className="pt-2 border-t flex justify-between">
              <span className="font-semibold">Total Amount:</span>
              <span className="text-xl font-bold text-primary">₹{billPreview.total.toFixed(2)}</span>
            </div>
          </div>
          <Button onClick={handleSubmit} disabled={isLoading} className="w-full mt-4">
            {isLoading ? "Saving..." : "Save Bill"}
          </Button>
        </Card>
      )}
    </div>
  );
};

export default BillGeneration;