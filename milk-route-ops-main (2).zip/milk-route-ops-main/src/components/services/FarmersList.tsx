import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Trash2, Search, Pencil } from "lucide-react";

interface Farmer {
  farmer_id: string;
  farmer_name: string;
  animal_type: string;
  contact_info: string;
  created_at: string;
}

const animalTypes = ["Cow", "Buffalo", "Goat", "Sheep", "Other"];

const FarmersList = () => {
  const [farmers, setFarmers] = useState<Farmer[]>([]);
  const [filteredFarmers, setFilteredFarmers] = useState<Farmer[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [editingFarmer, setEditingFarmer] = useState<Farmer | null>(null);
  const [editForm, setEditForm] = useState({ farmer_name: "", animal_type: "", contact_info: "" });
  const [isUpdating, setIsUpdating] = useState(false);
  const { toast } = useToast();

  const fetchFarmers = async () => {
    try {
      const { data, error } = await supabase
        .from("farmers")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setFarmers(data || []);
      setFilteredFarmers(data || []);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch farmers",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchFarmers();
  }, []);

  useEffect(() => {
    const filtered = farmers.filter(
      (farmer) =>
        farmer.farmer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        farmer.farmer_id.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredFarmers(filtered);
  }, [searchTerm, farmers]);

  const handleDelete = async (farmerId: string) => {
    try {
      setDeletingId(farmerId);
      const { error } = await supabase.from("farmers").delete().eq("farmer_id", farmerId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Farmer deleted successfully",
      });
      fetchFarmers();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete farmer. Make sure there are no associated records.",
        variant: "destructive",
      });
    } finally {
      setDeletingId(null);
    }
  };

  const openEditDialog = (farmer: Farmer) => {
    setEditingFarmer(farmer);
    setEditForm({
      farmer_name: farmer.farmer_name,
      animal_type: farmer.animal_type,
      contact_info: farmer.contact_info,
    });
  };

  const handleUpdate = async () => {
    if (!editingFarmer) return;
    try {
      setIsUpdating(true);
      const { error } = await supabase
        .from("farmers")
        .update({
          farmer_name: editForm.farmer_name,
          animal_type: editForm.animal_type,
          contact_info: editForm.contact_info,
        })
        .eq("farmer_id", editingFarmer.farmer_id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Farmer updated successfully",
      });
      setEditingFarmer(null);
      fetchFarmers();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update farmer",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  if (isLoading) {
    return <div className="text-center py-8">Loading farmers...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name or ID..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {filteredFarmers.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          {searchTerm ? "No farmers found matching your search" : "No farmers registered yet"}
        </div>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Farmer ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Animal Type</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredFarmers.map((farmer) => (
                <TableRow key={farmer.farmer_id}>
                  <TableCell className="font-medium">{farmer.farmer_id}</TableCell>
                  <TableCell>{farmer.farmer_name}</TableCell>
                  <TableCell>{farmer.animal_type}</TableCell>
                  <TableCell>{farmer.contact_info}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openEditDialog(farmer)}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="destructive"
                            size="sm"
                            disabled={deletingId === farmer.farmer_id}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Farmer</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete {farmer.farmer_name}? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDelete(farmer.farmer_id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={!!editingFarmer} onOpenChange={(open) => !open && setEditingFarmer(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Farmer</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Farmer Name</Label>
              <Input
                value={editForm.farmer_name}
                onChange={(e) => setEditForm({ ...editForm, farmer_name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Animal Type</Label>
              <Select value={editForm.animal_type} onValueChange={(value) => setEditForm({ ...editForm, animal_type: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {animalTypes.map((type) => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Contact Info</Label>
              <Input
                value={editForm.contact_info}
                onChange={(e) => setEditForm({ ...editForm, contact_info: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingFarmer(null)}>Cancel</Button>
            <Button onClick={handleUpdate} disabled={isUpdating}>
              {isUpdating ? "Updating..." : "Update"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default FarmersList;
