import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { format } from "date-fns";

interface ProductSale {
  product_id: string;
  product_name: string;
  quantity: number;
  price_per_unit: number;
  total_price: number;
  sale_date: string;
  created_at: string;
}

const productSchema = z.object({
  productName: z.string().trim().min(1, "Product name is required").max(100, "Product name must be less than 100 characters"),
  quantity: z.number().positive("Quantity must be positive").max(100000, "Quantity seems too high"),
  pricePerUnit: z.number().positive("Price must be positive").max(100000, "Price seems too high"),
});

const products = ["Butter", "Cheese", "Ghee", "Yogurt", "Paneer", "Cream", "Other"];

const DairyProducts = () => {
  const [formData, setFormData] = useState({
    productName: "",
    quantity: "",
    pricePerUnit: "",
  });
  const [totalPrice, setTotalPrice] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sales, setSales] = useState<ProductSale[]>([]);
  const [loadingSales, setLoadingSales] = useState(true);
  const { toast } = useToast();

  const fetchSales = async () => {
    try {
      const { data, error } = await supabase
        .from("products")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(20);

      if (error) throw error;
      setSales(data || []);
    } catch (error) {
      console.error("Failed to fetch sales:", error);
    } finally {
      setLoadingSales(false);
    }
  };

  useEffect(() => {
    fetchSales();
  }, []);

  const handleCalculate = () => {
    setErrors({});
    try {
      const quantity = parseFloat(formData.quantity);
      const pricePerUnit = parseFloat(formData.pricePerUnit);

      const validatedData = productSchema.parse({
        productName: formData.productName,
        quantity,
        pricePerUnit,
      });

      const total = validatedData.quantity * validatedData.pricePerUnit;
      setTotalPrice(total);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path) {
            newErrors[err.path[0]] = err.message;
          }
        });
        setErrors(newErrors);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (totalPrice === null) return;

    try {
      setIsLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase.from("products").insert({
        product_name: formData.productName,
        quantity: parseFloat(formData.quantity),
        price_per_unit: parseFloat(formData.pricePerUnit),
        total_price: totalPrice,
        created_by: user.id,
      });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Product sale recorded successfully",
      });
      setFormData({ productName: "", quantity: "", pricePerUnit: "" });
      setTotalPrice(null);
      fetchSales();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to record product sale",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-3">
        <div className="space-y-2">
          <Label htmlFor="productName">Product Name</Label>
          <Select onValueChange={(value) => setFormData({ ...formData, productName: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select product" />
            </SelectTrigger>
            <SelectContent>
              {products.map((product) => (
                <SelectItem key={product} value={product}>
                  {product}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.productName && <p className="text-sm text-destructive">{errors.productName}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="quantity">Quantity (kg/units)</Label>
          <Input
            id="quantity"
            type="number"
            step="0.01"
            placeholder="5.0"
            value={formData.quantity}
            onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
          />
          {errors.quantity && <p className="text-sm text-destructive">{errors.quantity}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="pricePerUnit">Price per Unit (₹)</Label>
          <Input
            id="pricePerUnit"
            type="number"
            step="0.01"
            placeholder="100.00"
            value={formData.pricePerUnit}
            onChange={(e) => setFormData({ ...formData, pricePerUnit: e.target.value })}
          />
          {errors.pricePerUnit && <p className="text-sm text-destructive">{errors.pricePerUnit}</p>}
        </div>
      </div>

      <Button onClick={handleCalculate} variant="outline">
        Calculate Total
      </Button>

      {totalPrice !== null && (
        <Card className="p-6 bg-gradient-to-br from-secondary/5 to-primary/5">
          <div className="flex justify-between items-center">
            <span className="text-lg font-semibold">Total Price:</span>
            <span className="text-2xl font-bold text-secondary">₹{totalPrice.toFixed(2)}</span>
          </div>
          <Button onClick={handleSubmit} disabled={isLoading} className="w-full mt-4">
            {isLoading ? "Saving..." : "Save Product Sale"}
          </Button>
        </Card>
      )}

      <div className="mt-8">
        <h3 className="text-lg font-semibold mb-4">Recent Product Sales</h3>
        {loadingSales ? (
          <div className="text-center py-4 text-muted-foreground">Loading sales...</div>
        ) : sales.length === 0 ? (
          <div className="text-center py-4 text-muted-foreground">No sales recorded yet</div>
        ) : (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Price/Unit</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sales.map((sale) => (
                  <TableRow key={sale.product_id}>
                    <TableCell>{format(new Date(sale.sale_date), "dd/MM/yyyy")}</TableCell>
                    <TableCell>{sale.product_name}</TableCell>
                    <TableCell>{sale.quantity}</TableCell>
                    <TableCell>₹{sale.price_per_unit}</TableCell>
                    <TableCell className="text-right font-medium">₹{sale.total_price}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </div>
  );
};

export default DairyProducts;