import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

const animalSchema = z.object({
  animalId: z.string().trim().min(1, "Animal ID is required").max(50, "Animal ID must be less than 50 characters"),
  farmerId: z.string().trim().min(1, "Farmer ID is required"),
  animalType: z.enum(["Cow", "Buffalo"], { required_error: "Please select an animal type" }),
});

const AddAnimal = () => {
  const [formData, setFormData] = useState({
    animalId: "",
    farmerId: "",
    animalType: "",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    try {
      const validatedData = animalSchema.parse(formData);
      setIsLoading(true);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Check if farmer exists
      const { data: farmer } = await supabase
        .from("farmers")
        .select("farmer_id")
        .eq("farmer_id", validatedData.farmerId)
        .single();

      if (!farmer) {
        toast({
          title: "Error",
          description: "Farmer ID not found",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      const { error } = await supabase.from("animals").insert({
        animal_id: validatedData.animalId,
        farmer_id: validatedData.farmerId,
        animal_type: validatedData.animalType,
        created_by: user.id,
      });

      if (error) {
        if (error.code === "23505") {
          toast({
            title: "Error",
            description: "Animal ID already exists",
            variant: "destructive",
          });
        } else {
          throw error;
        }
      } else {
        toast({
          title: "Success",
          description: "Animal added successfully",
        });
        setFormData({ animalId: "", farmerId: "", animalType: "" });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path) {
            newErrors[err.path[0]] = err.message;
          }
        });
        setErrors(newErrors);
      } else {
        toast({
          title: "Error",
          description: "Failed to add animal",
          variant: "destructive",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="animalId">Animal ID</Label>
          <Input
            id="animalId"
            placeholder="A001"
            value={formData.animalId}
            onChange={(e) => setFormData({ ...formData, animalId: e.target.value })}
          />
          {errors.animalId && <p className="text-sm text-destructive">{errors.animalId}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="farmerId">Farmer ID</Label>
          <Input
            id="farmerId"
            placeholder="F001"
            value={formData.farmerId}
            onChange={(e) => setFormData({ ...formData, farmerId: e.target.value })}
          />
          {errors.farmerId && <p className="text-sm text-destructive">{errors.farmerId}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="animalType">Animal Type</Label>
          <Select onValueChange={(value) => setFormData({ ...formData, animalType: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Cow">Cow</SelectItem>
              <SelectItem value="Buffalo">Buffalo</SelectItem>
            </SelectContent>
          </Select>
          {errors.animalType && <p className="text-sm text-destructive">{errors.animalType}</p>}
        </div>
      </div>
      <Button type="submit" disabled={isLoading} className="w-full md:w-auto">
        {isLoading ? "Adding..." : "Add Animal"}
      </Button>
    </form>
  );
};

export default AddAnimal;