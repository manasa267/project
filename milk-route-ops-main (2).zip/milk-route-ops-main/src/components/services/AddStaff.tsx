import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

const staffSchema = z.object({
  staffName: z.string().trim().min(2, "Name must be at least 2 characters").max(100, "Name must be less than 100 characters"),
  staffAge: z.number().min(18, "Age must be at least 18").max(100, "Age must be less than 100"),
  gender: z.enum(["Male", "Female", "Other"], { required_error: "Please select a gender" }),
  qualification: z.string().trim().min(2, "Qualification is required").max(100, "Qualification must be less than 100 characters"),
  contactInfo: z.string().trim().min(10, "Contact must be at least 10 characters").max(15, "Contact must be less than 15 characters"),
});

const AddStaff = () => {
  const [formData, setFormData] = useState({
    staffName: "",
    staffAge: "",
    gender: "",
    qualification: "",
    contactInfo: "",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    try {
      const validatedData = staffSchema.parse({
        ...formData,
        staffAge: parseInt(formData.staffAge),
      });
      setIsLoading(true);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase.from("staff").insert({
        staff_name: validatedData.staffName,
        staff_age: validatedData.staffAge,
        gender: validatedData.gender,
        qualification: validatedData.qualification,
        contact_info: validatedData.contactInfo,
        created_by: user.id,
      });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Staff member added successfully",
      });
      setFormData({ staffName: "", staffAge: "", gender: "", qualification: "", contactInfo: "" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path) {
            newErrors[err.path[0]] = err.message;
          }
        });
        setErrors(newErrors);
      } else {
        toast({
          title: "Error",
          description: "Failed to add staff member",
          variant: "destructive",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="staffName">Staff Name</Label>
          <Input
            id="staffName"
            placeholder="Jane Smith"
            value={formData.staffName}
            onChange={(e) => setFormData({ ...formData, staffName: e.target.value })}
          />
          {errors.staffName && <p className="text-sm text-destructive">{errors.staffName}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="staffAge">Age</Label>
          <Input
            id="staffAge"
            type="number"
            placeholder="25"
            value={formData.staffAge}
            onChange={(e) => setFormData({ ...formData, staffAge: e.target.value })}
          />
          {errors.staffAge && <p className="text-sm text-destructive">{errors.staffAge}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="gender">Gender</Label>
          <Select onValueChange={(value) => setFormData({ ...formData, gender: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select gender" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Male">Male</SelectItem>
              <SelectItem value="Female">Female</SelectItem>
              <SelectItem value="Other">Other</SelectItem>
            </SelectContent>
          </Select>
          {errors.gender && <p className="text-sm text-destructive">{errors.gender}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="qualification">Qualification</Label>
          <Input
            id="qualification"
            placeholder="B.Sc Agriculture"
            value={formData.qualification}
            onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
          />
          {errors.qualification && <p className="text-sm text-destructive">{errors.qualification}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="contactInfo">Contact Info</Label>
          <Input
            id="contactInfo"
            placeholder="9876543210"
            value={formData.contactInfo}
            onChange={(e) => setFormData({ ...formData, contactInfo: e.target.value })}
          />
          {errors.contactInfo && <p className="text-sm text-destructive">{errors.contactInfo}</p>}
        </div>
      </div>
      <Button type="submit" disabled={isLoading} className="w-full md:w-auto">
        {isLoading ? "Adding..." : "Add Staff Member"}
      </Button>
    </form>
  );
};

export default AddStaff;